        ###########################################################
        SDMI ortho-mosaic source scene shapefile - version: 2010.12
           www.alaskamapped.org   |    orthoproj@gina.alaska.edu
        ###########################################################

This is the shapefile for the accepted scenes for the 2011 collection season.

For further details on the project see:
   http://www.alaskamapped.org/ortho

To download the scenes you see here go to:
   http://browse.alaskamapped.org

If you have questions about this shapefile email:
  orthoproj@gina.alaska.edu 
